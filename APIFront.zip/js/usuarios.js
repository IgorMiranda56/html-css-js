document.addEventListener("DOMContentLoaded", carregarusuarios)

const carregarusuarios = () => {
    fetch("http://localhost:8080/usuarios")
    .then(response => {
        if(!response.ok){
            throw new Error("Erro ao buscar usuários.")
        }
        response.json()
    })
    .then(usuarios => {
        const lista = document.getElementById("listaUsuarios")
        lista.innerHTML = ""

        if(usuarios.lenght === 0){
            lista.innerHTML = "<li>Nenhum usuário encontrado. <li>"
            return
        }

        usuarios.forEach(usuario => {
            const item = document.createElement("li")
            item.innerHTML = `<strong>Nome: </strong> ${usuario.nome}<br>
            <strong>E-mail</strong> ${usuario.email}`
            lista.appendChild(item)
        })
    })
    .catch(erro => {
        document.getElementById("listaUsuario").innerHTML =
        "<li>Erro ao carregar usuários.</li>"
})
}