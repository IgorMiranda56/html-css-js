// src\components\Lista\index.js

import { useNavigate } from 'react-router-dom'
import ListaDeUsuarios from '../../components/ListaDeUsuarios'
import './style.css'

function PaginaListaUsuario(){
    const navigate = useNavigate()

    return(
        <div className='pagina-lista-usuarios'>
            <div>
                <h2>Lista de Usuarios</h2>
                <ListaDeUsuarios/>
                <button className='link-voltar' onClick={() => navigate('/')}>Cadastrar usuários</button>
            </div>
        </div>
    )
}

export default PaginaListaUsuario