package com.senai.aula4springfront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula4springfrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
