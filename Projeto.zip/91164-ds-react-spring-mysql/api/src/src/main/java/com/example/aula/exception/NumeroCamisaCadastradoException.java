package com.example.aula.exception;

public class NumeroCamisaCadastradoException extends RuntimeException {
    public NumeroCamisaCadastradoException(String message) {
        super(message);
    }
}
