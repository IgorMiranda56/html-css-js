// src\pages\Cadastro\index.js

import FormularioCadastro from '../../components/FormularioCadastro'
import { useNavigate } from 'react-router-dom'
import './styles.css'

function PaginaCadastro() {
    const navigate = useNavigate()
    
    return (
        <body>
        <div className='pagina-cadastro'>
            <FormularioCadastro/>
        </div>
        </body>
    )
}

export default PaginaCadastro