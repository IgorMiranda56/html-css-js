// src\components\TelaInicial\index.js

import React from 'react';
import logo from '../../assets/images/logo1.png'; 
import { useNavigate } from 'react-router-dom'
import './styles.css';

function TelaInicial(){
  const navigate = useNavigate()
  return (
    <body>
      <div className="tela-inicial">
      <ul id="listaUsuarios" className="lista-usuarios">
        <img src={logo} alt="Logo da empresa" />
        <h1>Bem-vindo!</h1>
        <button onClick={() => navigate('/cadastro')} className='link-voltar'>
          Cadastrar jogadores
        </button>
        <button onClick={() => navigate('/usuarios')} className="link-usuarios">
          Ver jogadores cadastrados
        </button>
      </ul>
      </div>
    </body>
  );
};

export default TelaInicial;