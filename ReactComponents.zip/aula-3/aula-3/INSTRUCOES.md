# Aula - ReactJs

### Criando projeto.

Comando no terminal.

```
npx create-react-app nome-projeto
```